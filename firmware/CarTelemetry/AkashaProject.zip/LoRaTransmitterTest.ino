// ============================================================
//  LoRaTransmitterTest.ino
//
//  Minimal test — sends "HELLO" to address 2 every 3 seconds.
//  Watch the receiver's Serial Monitor for +RCV lines.
//  Watch THIS Serial Monitor for AT responses.
//
//  Open Serial Monitor at 115200 baud.
// ============================================================

#define RXD1 9    // ESP32 RX ← LoRa TX
#define TXD1 8    // ESP32 TX → LoRa RX

int count = 0;

void setup() {
    Serial.begin(115200);
    Serial1.begin(115200, SERIAL_8N1, RXD1, TXD1);
    delay(2000);

    Serial.println("=== LoRa Transmitter Test ===\n");

    // Configure and print every response so you can see what's happening
    sendAndPrint("AT");
    sendAndPrint("AT+ADDRESS=1");
    sendAndPrint("AT+NETWORKID=5");
    sendAndPrint("AT+BAND=915000000");
    sendAndPrint("AT+PARAMETER?");
    sendAndPrint("AT+ADDRESS?");
    sendAndPrint("AT+NETWORKID?");
    sendAndPrint("AT+BAND?");

    Serial.println("\n--- Setup complete. Sending packets... ---\n");
}

void loop() {
    count++;

    // Build a simple test message
    String msg = "HELLO_" + String(count);
    int len = msg.length();

    String cmd = "AT+SEND=2," + String(len) + "," + msg;

    Serial.print("[TX #");
    Serial.print(count);
    Serial.print("]  ");
    Serial.print(cmd);
    Serial.print("  -->  ");

    // Send and show response
    sendAndPrint(cmd);

    // Also print anything the module sends back (like errors)
    delay(500);
    while (Serial1.available()) {
        Serial.write(Serial1.read());
    }

    Serial.println();
    delay(3000);
}

// Send an AT command and print the response
void sendAndPrint(String cmd) {
    // Flush any stale data
    while (Serial1.available()) Serial1.read();

    Serial1.println(cmd);

    unsigned long start = millis();
    String response = "";

    while (millis() - start < 1000) {
        while (Serial1.available()) {
            char c = Serial1.read();
            response += c;
        }
        if (response.indexOf("+OK") >= 0 || response.indexOf("+ERR") >= 0) {
            break;
        }
    }

    response.trim();

    if (response.length() == 0) {
        Serial.println("[NO RESPONSE]");
    } else {
        Serial.println(response);
    }
}
