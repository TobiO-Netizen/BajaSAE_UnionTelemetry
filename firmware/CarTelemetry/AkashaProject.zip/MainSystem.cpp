#include "MainSystem.h"
#include <Wire.h>
#include <lvgl.h>

// SquareLine Studio screens — defined in ui.h
extern lv_obj_t *ui_Baja;
extern lv_obj_t *ui_OBDII;

// -- CSV header matching buildCSVRow() --
static const char *CSV_HEADER =
    "millis,packetNum,"
    "accelX_g,accelY_g,accelZ_g,"
    "gyroX,gyroY,gyroZ,"
    "objTempF,ambTempF,"
    "forceN,forceLbf,"
    "lat,lon,alt_m,speedMph,satellites,"
    "rpm,obdSpeedMph,coolantF,throttle,"
    "timestamp";

// ---------------------------------------------------------------
bool MainSystem::begin() {
    Serial.begin(DEBUG_BAUD);
    delay(1000);

    // Deselect all SPI devices immediately — prevents bus collisions
    pinMode(SCREEN_CS_PIN, OUTPUT);
    digitalWrite(SCREEN_CS_PIN, HIGH);
    pinMode(SD_CS_PIN, OUTPUT);
    digitalWrite(SD_CS_PIN, HIGH);

    Serial.println(F("\n============================"));
    Serial.println(F("  Car Telemetry System"));
    Serial.println(F("============================\n"));

    bool allOk = true;

    // -- MPU6050 --
    Serial.print(F("[MPU6050]  Initialising... "));
    if (mpu.begin()) {
        Serial.println(F("OK"));
        Serial.println(F("           Calibrating — keep vehicle still..."));
        mpu.calibrate(300);
        Serial.println(F("           Calibration done."));
    } else {
        Serial.println(F("FAIL"));
        allOk = false;
    }

    // -- Temp sensor --
    Serial.print(F("[MLX90614] Initialising... "));
    if (temp.begin()) {
        Serial.println(F("OK"));
    } else {
        Serial.println(F("FAIL"));
        allOk = false;
    }

    // -- Strain gauge / HX711 --
    Serial.print(F("[HX711]    Initialising... "));
    if (strain.begin(HX711_DOUT_PIN, HX711_SCK_PIN, HX711_GAIN)) {
        Serial.println(F("OK"));
        Serial.println(F("           Taring — remove all load..."));
        strain.tare(20);
        strain.setCalibrationFactor(HX711_CAL_FACTOR);
        Serial.println(F("           Tare done."));
    } else {
        Serial.println(F("FAIL"));
        allOk = false;
    }

    // -- GPS --
    Serial.print(F("[GPS]      Initialising... "));
    if (gps.begin(Serial2)) {
        Serial.println(F("OK  (waiting for fix)"));
    } else {
        Serial.println(F("FAIL"));
        allOk = false;
    }

    // -- SD Card --
    Serial.print(F("[SD Card]  Mounting... "));
    if (sd.begin()) {
        Serial.println(F("OK"));
        sd.openNewLog("TEL");
        sd.writeHeader(CSV_HEADER);
        Serial.print(F("           Log file: "));
        Serial.println(sd.logFilename());
    } else {
        Serial.println(F("FAIL — logging disabled"));
    }

    // -- LoRa --
    Serial.print(F("[LoRa]     Initialising... "));
    if (lora.begin(Serial1)) {
        Serial.println(F("OK"));
    } else {
        Serial.println(F("FAIL"));
        allOk = false;
    }

    // -- OBD2 / CAN Bus --
    Serial.print(F("[OBD2]     Initialising CAN bus... "));
    if (obd.begin(CAN_TX_PIN, CAN_RX_PIN)) {
        Serial.println(F("OK"));
        Serial.print(F("           Detecting ECU... "));
        if (obd.isConnected()) {
            Serial.println(F("CONNECTED"));
            _obdConnected = true;
            obd.startPolling();
            Serial.println(F("           Background polling started on core 0"));
        } else {
            Serial.println(F("NOT DETECTED (car off or not plugged in)"));
            _obdConnected = false;
        }
    } else {
        Serial.println(F("FAIL"));
        _obdConnected = false;
    }

    Serial.println();
    Serial.println(allOk ? F("All systems GO.")
                         : F("Some modules failed — check wiring."));
    if (_obdConnected) {
        Serial.println(F("OBD2 active — logging engine data."));
        lv_scr_load(ui_OBDII);
    } else {
        Serial.println(F("OBD2 inactive — sensor-only mode."));
        lv_scr_load(ui_Baja);
    }
    Serial.println();

    unsigned long now = millis();
    _lastSensorMs = now;
    _lastLogMs    = now;
    _lastLoraMs   = now;

    return allOk;
}

// ---------------------------------------------------------------
void MainSystem::update() {
    unsigned long now = millis();

    // -- Sensor reads --
    if (now - _lastSensorMs >= MAIN_LOOP_INTERVAL_MS) {
        _lastSensorMs = now;
        readAllSensors();
    }

    // -- SD logging --
    if (now - _lastLogMs >= SD_LOG_INTERVAL_MS) {
        _lastLogMs = now;
        logToSD();
    }

    // -- LoRa transmit --
    if (now - _lastLoraMs >= LORA_SEND_INTERVAL_MS) {
        _lastLoraMs = now;
        transmitLoRa();
    }

    // Always feed GPS bytes
    gps.update();

    // -- OBD2 hot-plug detection (every 5 seconds) --
    static unsigned long lastObdCheck = 0;
    if (now - lastObdCheck >= 5000) {
        lastObdCheck = now;
        bool wasConnected = _obdConnected;
        _obdConnected = obd.isConnected();

        if (_obdConnected && !wasConnected) {
            obd.startPolling();
            lv_scr_load_anim(ui_OBDII, LV_SCR_LOAD_ANIM_FADE_IN, 300, 0, false);
            Serial.println(F("[OBD2]   ECU detected — switching to OBD screen"));
        } else if (!_obdConnected && wasConnected) {
            obd.stop();
            lv_scr_load_anim(ui_Baja, LV_SCR_LOAD_ANIM_FADE_IN, 300, 0, false);
            Serial.println(F("[OBD2]   ECU lost — switching to sensor screen"));
        }
    }

    // Check for incoming LoRa commands
    if (lora.receive()) {
        Serial.print(F("[LoRa RX] "));
        Serial.println(lora.lastMessage());
    }
}

// ---------------------------------------------------------------
void MainSystem::readAllSensors() {
    mpu.update();
    temp.update();
    strain.update();

    const MPU6050Reading &m = mpu.getReading();
    Serial.printf("[Accel]  X=%.2f Y=%.2f Z=%.2f g\n",
                  m.accel.x, m.accel.y, m.accel.z);
    Serial.printf("[Gyro]   X=%.1f Y=%.1f Z=%.1f deg/s\n",
                  m.gyro.x, m.gyro.y, m.gyro.z);
    Serial.printf("[Temp]   Obj=%.1fF  Amb=%.1fF\n",
                  temp.getObjectTempF(), temp.getAmbientTempF());
    Serial.printf("[Strain] %.2f N  (%.2f lbf)\n",
                  strain.getForceN(), strain.getForceLbf());

    if (gps.hasFix()) {
        const GPSData &g = gps.getData();
        Serial.printf("[GPS]    %.6f, %.6f  alt=%.1fm  speed=%.1fmph  sats=%d  %s\n",
                      g.latitude, g.longitude, g.altitude,
                      g.speedMph, g.satellites, gps.timestamp().c_str());
    } else {
        Serial.println(F("[GPS]    No fix yet"));
    }

    if (_obdConnected) {
        OBDData o = obd.getSnapshot();
        Serial.printf("[OBD2]   RPM=%.0f  Spd=%.0fmph  Coolant=%.0fF  Thr=%.1f%%\n",
                      o.rpm, o.speedMph, o.coolantF, o.throttle);
    }
}

// ---------------------------------------------------------------
String MainSystem::buildCSVRow() {
    const MPU6050Reading &m = mpu.getReading();
    const GPSData        &g = gps.getData();

    char row[320];

    if (_obdConnected) {
        OBDData o = obd.getSnapshot();
        snprintf(row, sizeof(row),
            "%lu,%lu,"
            "%.3f,%.3f,%.3f,"
            "%.2f,%.2f,%.2f,"
            "%.1f,%.1f,"
            "%.2f,%.2f,"
            "%.6f,%.6f,%.1f,%.1f,%d,"
            "%.0f,%.1f,%.1f,%.1f,"
            "%s",
            millis(), _packetCount,
            m.accel.x, m.accel.y, m.accel.z,
            m.gyro.x,  m.gyro.y,  m.gyro.z,
            temp.getObjectTempF(), temp.getAmbientTempF(),
            strain.getForceN(), strain.getForceLbf(),
            g.latitude, g.longitude, g.altitude,
            g.speedMph, g.satellites,
            o.rpm, o.speedMph, o.coolantF, o.throttle,
            gps.timestamp().c_str()
        );
    } else {
        snprintf(row, sizeof(row),
            "%lu,%lu,"
            "%.3f,%.3f,%.3f,"
            "%.2f,%.2f,%.2f,"
            "%.1f,%.1f,"
            "%.2f,%.2f,"
            "%.6f,%.6f,%.1f,%.1f,%d,"
            ",,,,"
            "%s",
            millis(), _packetCount,
            m.accel.x, m.accel.y, m.accel.z,
            m.gyro.x,  m.gyro.y,  m.gyro.z,
            temp.getObjectTempF(), temp.getAmbientTempF(),
            strain.getForceN(), strain.getForceLbf(),
            g.latitude, g.longitude, g.altitude,
            g.speedMph, g.satellites,
            gps.timestamp().c_str()
        );
    }
    return String(row);
}

String MainSystem::buildLoRaPayload() {
    // pkt|aX|aY|aZ|gX|gY|gZ|spdMph|objF|forceN|lat|lon|sats
    const MPU6050Reading &m = mpu.getReading();
    const GPSData        &g = gps.getData();

    char buf[160];
    snprintf(buf, sizeof(buf),
        "%lu|%.2f|%.2f|%.2f|%.1f|%.1f|%.1f|%.1f|%.1f|%.2f|%.6f|%.6f|%d",
        _packetCount,
        m.accel.x, m.accel.y, m.accel.z,
        m.gyro.x,  m.gyro.y,  m.gyro.z,
        g.speedMph,
        temp.getObjectTempF(),
        strain.getForceN(),
        g.latitude, g.longitude,
        g.satellites
    );
    return String(buf);
}

void MainSystem::logToSD() {
    if (!sd.isReady()) return;
    sd.appendLine(buildCSVRow());
    if (_packetCount % 10 == 0) sd.flush();
}

void MainSystem::transmitLoRa() {
    _packetCount++;
    String payload = buildLoRaPayload();

    Serial.print(F("[LoRa TX] "));
    Serial.println(payload);

    lora.send(payload);
}
