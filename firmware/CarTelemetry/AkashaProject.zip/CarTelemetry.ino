// ============================================================
//  CarTelemetry.ino
//
//  Top-level Arduino sketch.
//  All logic lives in MainSystem and its sub-modules.
//  Edit Config.h to change pin assignments and timing.
// ============================================================

#include "MainSystem.h"

MainSystem sys;

void setup() {
    sys.begin();
}

void loop() {
    sys.update();
}
